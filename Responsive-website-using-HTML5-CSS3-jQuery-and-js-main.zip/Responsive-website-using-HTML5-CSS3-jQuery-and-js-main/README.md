# Responsive-website-using-HTML5-CSS3-jQuery-and-js
A fully Responsive website using HTML5, CSS3, jQuery and js.
This website for omnifood, and user can edit as they want.
